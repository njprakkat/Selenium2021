package JavaCodes;
// to print only odd numbers
// 0 1 2 3 4 5 6 7 8 9 10
// skip when i see a even number

public class ContinueDemo 
{ 
    public static void main(String args[]) 
    { 
        for (int i = 0; i <=10; i++) 
        { 
            // If the number is even 
            // skip and continue 
            if (i%2 == 0) //even number
                continue;  // control goes to Line no 11
            	            
            // If number is odd, print it 
            System.out.print(i + " "); 
        } 
    } 
} 