package JavaCodes;

public class CountChar {

	public void mthd1() {
			String str = "Welcome to Chennai";
			int count=0;
			char[] charArray = str.toCharArray();
			for (int i = 0; i < charArray.length; i++) {
				
				if(charArray[i]=='e') {
					count++;
				}
			}
			System.out.println("cont of e is :" + count);
		}
	
	public void mthd2() {
		String str = "welcome to chennai ";
		// Declare and intialize the count
		int count = 0;
		
		char[] ch = str.toCharArray();
		
		for (int i = 0; i < ch.length; i++) {
			System.out.println(ch[i]);
			if (ch[i] =='e')
			{ count++; }
		}
		System.out.println("Occurence of e is: "+count);	
	}
	
	 // count of e
	// charArray
	public static void main(String[] args) {
		CountChar obj = new CountChar();
		obj.mthd1();
		obj.mthd2();

}
}
