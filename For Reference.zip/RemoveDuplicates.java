package JavaCodes;

public class RemoveDuplicates {

	public static void main(String[] args) {
		int j;
		String text = "We learn java basics as part of Java sessions in java week1";
		String[] words;
		words = text.split("\\s");
		for (int i = 0; i < words.length; i++) {
			for (j = i+1; j < words.length; j++) {
				if (words[i].equalsIgnoreCase(words[j])) {
					words[j] = "";
		        	}
				}
	    	}
		System.out.println("String without duplicates: ");
		for (int k = 0; k < words.length; k++) {
			System.out.println(words[k]);
		}
	}
}
